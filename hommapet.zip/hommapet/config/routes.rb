Rails.application.routes.draw do
  devise_for :users

  get 'tweets/dog' => 'tweets#dog'
  get 'tweets/cat' => 'tweets#cat'
  get 'tweets/rabbit' => 'tweets#rabbit'
  get 'tweets/bird' => 'tweets#bird'
  get 'tweets/hamster' => 'tweets#hamster'
  get 'tweets/others' => 'tweets#others'

  resources :tweets
  root 'tweets#index'
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html

 

end
